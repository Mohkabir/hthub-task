License: Free for commercial use

The university project was to create our own modified display font by using a previously chosen typeface. I wanted to remake a version of Lora typeface.

Made by: Veres Anikó
Made at the Media and Design Department, Visual Arts Institue, Eger, Hungary 

https://www.behance.net/veresaniko



